# Food Kundali — Improvement Plan (Strict 6-File Architecture)

A focused upgrade roadmap for **Food Kundali** (*Apna khana, apni kundali*) that improves reliability, code maintainability, layout stability, and everyday usability while **strictly staying within the existing 6 files** (`index.html`, `style.css`, `data.js`, `core.js`, `features.js`, `README.md`), keeping the **current visual look completely unchanged**, and preserving 100% compatibility with all saved user data.

> [!IMPORTANT]
> **User Review & Critical Decisions**
> - **Visual Look Locked**: Per your choice, the existing calm green/amber theme, typography, card shapes, and screen layouts remain untouched — styling changes are strictly limited to fixing real layout glitches, dark-mode contrast defects, and removing dead/duplicate CSS overrides.
> - **Strict 6-File Constraint**: Zero new files, zero build tools, zero external runtime dependencies. The fixed script load order (`data.js` → `core.js` → `features.js`) stays intact.
> - **Data Safety Guarantee**: Every existing `fk_*` `localStorage` key (`fk_foods_v3`, `fk_personal_v1`, `fk_central_profile_v1`, `fk_fc`, `fk_lang`, `fk_theme`, `fk_det`, etc.) remains backward-compatible so no user diary, profile, or plate data is ever lost.
> - **Scope Check**: Since priority areas and new features were left open, this plan prioritizes **(1) Bug fixes & code/CSS cleanup**, **(2) Layout glitch fixes**, and **(3) High-value everyday upgrades** (Custom Foods, typo-tolerant Hinglish search + diet filter, browser Back-button navigation, and Diary quick-add + 7-day visual bars). Please confirm if you want all 4 phases implemented or only specific phases.

---

## 1. Overview & Core Concept

Food Kundali already delivers a rich offline Indian nutrition experience — 264 food entries (220 unique food groups), 245 curated "Why should I eat" guides, ICMR-NIN 2020 + Mifflin-St Jeor Calculator, Compare tool, Nutrient Explorer, Food Diary, Water Tracker, and Canvas Share Cards.

However, rapid iterative feature additions (across v28–v37 and Phases 1–4) left behind **real functional bugs**, **heavy CSS/JS layering debt** (118.7 KB stylesheet with 81 `!important` rules; 5 nested monkey-patches on view switching), **mobile/desktop layout glitches**, and a few **high-friction daily gaps** (no way to log homemade/packaged custom foods, no browser Back support, exact-only Hinglish search).

### Improvement Pillars (Ordered by Priority)
1. **Fix Confirmed Functional Bugs**: Repair the broken Share Image swap hint, replace all 9 blocking `alert()`/`confirm()` popups with the native in-app `<dialog>`, eliminate redundant boot-time storage writes, and clean up dead code.
2. **Fix Layout Glitches & Clean Up Layered Code**: Deduplicate conflicting CSS rules (without changing how the app looks), fix desktop bottom-bar alignment, dark-mode contrast defects, and narrow-screen (360px) overflow glitches, and consolidate the 5+4 view-switching monkey-patches into a single deterministic router.
3. **Add Practical Everyday Capabilities (Zero Extra Files)**:
   - **Custom Food Entry (*Apna Food Jodo*)**: Add, edit, and delete homemade or packaged foods stored separately from seed data so database updates never overwrite them.
   - **Smarter Hinglish Search & Diet Filter**: Typo-tolerant and phonetic Hinglish matching (e.g., `paalak`, `panir`, `chaawal`) plus quick `All / Veg / Egg / Non-Veg` filtering synced with the Central Profile.
   - **Browser Back-Button & Faster Tool Switching**: Real `history.pushState` / `popstate` navigation plus direct links to Compare, Foods by Nutrient, and Profile inside the top-right menu.
   - **Diary Workflow Upgrades**: One-tap Quick-Add from Favourites/Recent, per-meal calorie & protein subtotals, and lightweight 7-day progress bars inside the existing Diary card.

---

## 2. User Experience & Visual Design

### Design Constraint: Preserve Current Look, Fix Glitches Only
The existing visual identity — warm sage background (`#f2f6ec`), crisp white cards, forest green primary accent (`#2c7a4b`), amber secondary accent (`#e3a62a`), purple calculator accent (`#7a4fc0`), dark mode palette (`#101a14` / `#182419`), and 620px / 760px centered column — will be **preserved pixel-for-pixel** on healthy screens.

### Targeted Layout & Accessibility Glitches to Fix
| Area | Current Glitch Found in Audit | Planned Fix (Zero Visual Redesign) |
| :--- | :--- | :--- |
| **Bottom Tab Bar (`.bbar`)** | On screens wider than 880px, `.btab` caps at `max-width: 220px` inside a `display: flex` bar with no centering, causing all 4 tabs to hug the left edge. | Add `justify-content: center` to `.bbar` so tabs stay balanced across desktop and tablet screens. |
| **Non-Practical Chip Contrast** | `.npchip .npcalc` forces `color: #000` on top of a dark red gradient chip, creating poor legibility. | Switch to high-contrast `#fff` with subtle opacity so calculation text meets WCAG AA contrast. |
| **Food Classification Popover (`.food-label-details`)** | Uses `position: absolute` plus JS collision polling (`flFitCard`) that can crowd long Hinglish names or overlap `.tags` on 360px screens. | Stabilize flex/grid reservation inside `.hero` and clamp popover max-width cleanly on narrow viewports so text never collides. |
| **Nutrient Table on 360px Viewports** | When Detailed View + Custom Amount + Fat Breakdown are open simultaneously, table columns squeeze tightly and badges can wrap awkwardly. | Apply `font-variant-numeric: tabular-nums` across nutrient/macro numbers and refine 360px column proportions to prevent cramped wrapping. |
| **Calculator Step Connector (`.fcsteps`)** | Redefined 7 times across `style.css` (originally 3 columns, later overridden to 2), causing fragile specificity conflicts. | Consolidate into a single clean 2-column rule matching the actual 2-step markup. |
| **Touch Targets & Native Popups** | 9 `alert()`/`confirm()` calls break immersion and fail inside iFrames/WebViews; a few secondary icon buttons sit below 44px. | Route all confirmations/notices through the styled `<dialog id="dlg">` component and ensure every interactive control maintains at least a `44×44px` hit target. |
| **Reduced Motion & Focus** | Mostly covered, but several newer transitions skip `prefers-reduced-motion` and focus outlines vary between accent colors. | Ensure consistent `focus-visible` rings and full reduced-motion compliance across all interactive disclosures. |

### New UX Flows (Blended Seamlessly into Existing Screens)
- **Custom Foods (*Apna Food Jodo*)**: Accessible from the **Saved** tab (alongside Favourites & Recent) and from the **"Food not found"** empty search state. Opens an inline form inside the existing card style (Name, English/Hinglish alias, Category, Serving size in g, Calories, Protein, Carbs, Fat, Fiber — optional micronutrients). Custom foods behave identically to built-in foods across Search, Calculator, Compare, Diary, and Share Image, and are automatically included in JSON Backup/Restore.
- **Smarter Search + Quick Diet Filter**: Typing `panir`, `paalak`, `chole`, or `chiken` surfaces the right foods immediately via lightweight phonetic folding + 1-edit typo tolerance. A compact single-row diet toggle (`All · Veg · Egg · Non-Veg`) inside the browse/search flow filters results without altering the home screen hierarchy.
- **Navigation & Back Button**: Switching between Home, Calculator, Diary, Saved, Compare, Nutrients, and Profile pushes clean hash/history states so pressing the phone/browser Back button returns to the previous view instead of leaving the app. Compare, Nutrients, and Profile are also added to the top-right menu so users can jump between tools from any screen.
- **Diary Quick-Add & 7-Day Visual Bars**: Each meal section (Breakfast, Lunch, Snacks, Dinner) displays a compact kcal + protein subtotal in its header. A "Quick add from Saved/Recent" strip sits right inside the Diary add flow, and the existing 7-day overview renders crisp horizontal progress bars against the user's daily calorie and water targets.

---

## 3. Key Product Decisions & Trade-Offs

1. **Consolidating CSS Without Changing Visual Appearance**
   - *Decision*: Deduplicate the 118.7 KB stylesheet (merging the 7 `.fcsteps` blocks, 3 stacked `#cp .cp-table` redesigns, and removing dead v28 `.fchero`/`.fcdonut`/`.fcsnapshot`/`.cp-fatpanel` rules) while keeping every active selector and visual property identical.
   - *Trade-off*: Requires careful visual verification across Light/Dark themes and all 7 views (Home, Food Detail, Calculator, Compare, Nutrients, Diary/Saved, Profile) so zero unintended visual drift occurs.

2. **Separating Custom Foods Storage (`fk_custom_foods_v1`) from Seed Cache (`fk_foods_v3`)**
   - *Decision*: Store user-created foods in a dedicated `fk_custom_foods_v1` key and merge them into `DB` in memory on load.
   - *Trade-off*: Slightly more logic in `DB.load()` and Backup/Restore, but **completely eliminates the risk** of future `DATA_VER` bumps wiping user-created foods (currently, `DB.load()` strips any food ID not found in `SEED` whenever `DATA_VER` changes!).

3. **Zero-Dependency Fuzzy Hinglish Search**
   - *Decision*: Implement a compact (~40 lines) phonetic normalizer (`aa→a`, `ee→i`, `oo→u`, `ph→f`, `bh/dh/kh/gh/th` simplification) plus bounded Levenshtein distance (max 1 edit for 4–6 chars, max 2 for 7+ chars) directly inside `core.js`.
   - *Trade-off*: Runs in <2ms across 264+ foods with zero external libraries, keeping the app 100% offline and instant on low-end Android phones.

4. **Replacing 5+4 View-Switching Monkey-Patches with a Unified View Router**
   - *Decision*: Replace the layered `var oldFcTab = fcTab; fcTab = function(...)` chains in `features.js` with one central `openView(view, opts)` dispatcher that coordinates active sections, bottom-bar highlighting, return buttons, scroll position, and `history.pushState`.
   - *Trade-off*: Still preserves public function names (`fcTab`, `fcNav`, `openCompare`, `openPersonal`, `openProfile`) as thin wrappers so no existing handlers or expectations break.

5. **Exposing "Why Should I Eat" Helpers Safely for Share Image**
   - *Decision*: Expose a small read-only helper (`window.FK_WHY = { calc, better }`) from the Why IIFE so `siSwap(f)` works reliably on Share Image cards.
   - *Trade-off*: Minimal global surface (one namespaced object), immediately unlocking the already-written swap recommendation banner in exported 9:16 images.

---

## 4. Technical Architecture & Data Strategy

### 6-Module Architecture & Strict Load Order
The application preserves its zero-build, 6-file offline structure while cleaning up internal boundaries:

```
┌──────────────────────────────────────────────────────────────────────────┐
│  1. Markup Shell (index.html)                                            │
│     • Header + Settings/Tools Menu (#mp) + Search Box + Quick Tiles      │
│     • Views: #out | #fc | #nv | #cp | #personal | #profilePage           │
│     • Bottom Tab Bar (#bbar) + Shared Modal Dialog (#dlg)                │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ Styled by (2) style.css
                                   │ (Deduplicated tokens, dark mode,
                                   │  fixed glitches, zero visual drift)
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  3. Static Dataset & i18n (data.js)                                      │
│     • NUT (21 nutrients) · SEED (base foods) · LANG (English/Hinglish)   │
│     • No runtime DOM dependency; pure data declarations                  │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ Loaded 1st
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  4. Core Engine & Storage Layer (core.js)                                │
│     • Single-pass boot: SEED + Indian/USDA additions + fix37 (1 save)    │
│     • Non-destructive merge of custom foods (fk_custom_foods_v1)         │
│     • Fuzzy Hinglish + Diet-aware DB.search(query, dietFilter)           │
│     • Benefits ranking engine (BEN / USE / USE_PRIORITY_34)              │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ Loaded 2nd
                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  5. Feature Controllers & Unified Router (features.js)                   │
│     • Unified View Router + History API (pushState / popstate)           │
│     • Custom Dialog Helpers (modalAlert / modalConfirm via #dlg)         │
│     • Food Kundali Detail · Calculator · Compare · Nutrients             │
│     • Diary (Quick-Add + Meal Subtotals + 7-Day Bars) · Custom Food UI   │
│     • "Why Should I Eat" (exposes FK_WHY) ──► Canvas Share Image (siSwap)│
└──────────────────────────────────────────────────────────────────────────┘
  6. Documentation (README.md) — Updated to accurately list all 6 files,
     food counts, custom-food key, and edit/maintenance map.
```

### Data & Storage Flow (100% Backward-Compatible)

```
  localStorage (Existing Keys — Unchanged)
  ├── fk_foods_v3          ──► Cached built-in food dataset (synced via fk_data_ver)
  ├── fk_lang / fk_theme   ──► Bilingual & Light/Dark preferences
  ├── fk_det               ──► Detailed nutrient table toggle
  ├── fk_fc                ──► Food Calculator plate & profile state
  ├── fk_personal_v1       ──► Diary entries, water tracker, favourites, recent
  ├── fk_central_profile_v1──► Central Profile (age, goal, diet, Under-19 guard)
  └── fk_seen_intro        ──► Welcome card dismissal

  localStorage (1 Additive Key — Safe Across Upgrades)
  └── fk_custom_foods_v1   ──► User-created custom foods (id prefix: "custom_")
                               • Survives DATA_VER upgrades automatically
                               • Exported & imported in Diary JSON Backup/Restore
```

### Boot Optimization & Bug-Fix Checklist
1. **Single-Write Boot (`core.js`)**: Assemble `SEED` + Indian/recipe additions + USDA additions + `fix37` once before comparing/writing to `fk_foods_v3`, avoiding 3 redundant `JSON.stringify` writes on every page open.
2. **Fix `siSwap(f)` (`features.js`)**: Wire `calc` and `better` from the Why module into `siSwap(f)` so Share Image cards actually display healthier swap hints when a nutrient flags red.
3. **Replace All 9 `alert()`/`confirm()` Calls (`features.js`)**: Route storage warnings, copy-previous-day confirmation, and JSON backup import/restore confirmations through `openDlg()` with accessible focus management.
4. **Remove Dead Code (`core.js`, `features.js`, `style.css`)**:
   - Remove dead `initCalcDD()` / `#cpre` hook, unused `fcOverview()`/`fcMini()`, and orphan `WI.water` entry (confirm `water_drinking` coverage).
   - Strip dead CSS blocks (`.fchero`, `.fcdonut`, `.fcsnapshot`, `.cp-fatpanel`, redundant `#cp .cp-table` earlier passes) and bring `!important` count down from 81 to near zero.
5. **Sync Documentation (`README.md`)**: Update "Files (5)" → "Files (6)", document the unified router, custom food storage key, and browser history behavior.

### Implementation Roadmap (4 Clean Passes After Approval)
- **Pass 1 — Stability & Cleanup**: Fix `siSwap`, replace 9 `alert()`/`confirm()` calls, optimize single-pass DB boot, remove dead JS/CSS, deduplicate `style.css`, and fix all audited layout & contrast glitches.
- **Pass 2 — Unified Navigation & History**: Replace the 5+4 `fcTab`/`fcNav` monkey-patches with one router, add `pushState`/`popstate` browser Back support, and add Compare / Nutrients / Profile links to the header menu.
- **Pass 3 — Everyday Features**: Add Custom Foods (*Apna Food Jodo*) with backup integration, typo-tolerant Hinglish search + dietary filter, and Diary Quick-Add + meal subtotals + 7-day visual bars.
- **Pass 4 — Verification & README Sync**: Verify all 7 views in Light & Dark modes, mobile (360px/390px) and desktop (1280px+) widths, test localStorage migration & JSON backup/restore, and update `README.md`.
